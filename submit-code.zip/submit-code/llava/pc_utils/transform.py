"""
This file is modified from PonderV2

"""

import os
import copy
import numbers
import random
from collections.abc import Mapping, Sequence
from typing import List, Optional, Sequence, Tuple, Union

import numpy as np
import scipy
import scipy.interpolate
import scipy.ndimage
import scipy.stats
import torch
import math

from .registry import Registry

from torch_geometric.utils import scatter

TRANSFORMS = Registry("transforms")


@TRANSFORMS.register_module()
class Collect(object):
    def __init__(
        self, keys, offset_keys_dict=dict(offset="coord"), stack_keys=(), **kwargs
    ):
        """
        e.g. Collect(keys=[coord], feat_keys=[coord, color])
        """
        self.keys = keys
        self.stack_keys = stack_keys
        self.offset_keys = offset_keys_dict
        self.kwargs = kwargs

    def __call__(self, data_dict):
        data = dict()
        for key in self.keys:
            data[key] = data_dict[key]
        for key in self.stack_keys:
            data[key] = data_dict[key][None, ...]
        for key, value in self.offset_keys.items():
            data[key] = torch.tensor([data_dict[value].shape[0]])
        for name, keys in self.kwargs.items():
            name = name.replace("_keys", "")
            assert isinstance(keys, Sequence)
            data[name] = torch.cat([data_dict[key].float() for key in keys], dim=1)

        return data


@TRANSFORMS.register_module()
class Copy(object):
    def __init__(self, keys_dict=None):
        if keys_dict is None:
            keys_dict = dict(coord="origin_coord", segment="origin_segment")
        self.keys_dict = keys_dict

    def __call__(self, data_dict):
        for key, value in self.keys_dict.items():
            if isinstance(data_dict[key], np.ndarray):
                data_dict[value] = data_dict[key].copy()
            elif isinstance(data_dict[key], torch.Tensor):
                data_dict[value] = data_dict[key].clone().detach()
            else:
                data_dict[value] = copy.deepcopy(data_dict[key])
        return data_dict


@TRANSFORMS.register_module()
class ToTensor(object):
    def __call__(self, data):
        if isinstance(data, torch.Tensor):
            return data
        elif isinstance(data, str):
            # note that str is also a kind of sequence, judgement should before sequence
            return data
        elif isinstance(data, int):
            return torch.LongTensor([data])
        elif isinstance(data, float):
            return torch.FloatTensor([data])
        elif isinstance(data, np.ndarray) and np.issubdtype(data.dtype, bool):
            return torch.from_numpy(data)
        elif isinstance(data, np.ndarray) and np.issubdtype(data.dtype, np.integer):
            return torch.from_numpy(data).long()
        elif isinstance(data, np.ndarray) and np.issubdtype(data.dtype, np.floating):
            return torch.from_numpy(data).float()
        elif isinstance(data, Mapping):
            result = {sub_key: self(item) for sub_key, item in data.items()}
            return result
        elif isinstance(data, Sequence):
            result = [self(item) for item in data]
            return result
        else:
            raise TypeError(f"type {type(data)} cannot be converted to tensor.")


@TRANSFORMS.register_module()
class Add(object):
    def __init__(self, keys_dict=None):
        if keys_dict is None:
            keys_dict = dict()
        self.keys_dict = keys_dict

    def __call__(self, data_dict):
        for key, value in self.keys_dict.items():
            data_dict[key] = value
        return data_dict


@TRANSFORMS.register_module()
class NormalizeColor(object):
    def __call__(self, data_dict):
        if "color" in data_dict.keys():
            data_dict["color"] = data_dict["color"] / 127.5 - 1
        if "rgb" in data_dict.keys():
            data_dict["rgb"] = (data_dict["rgb"] / 255.0).clip(0, 1)
        return data_dict


@TRANSFORMS.register_module()
class NormalizeCoord(object):
    def __init__(self, keys=[]):
        self.keys = keys

    def __call__(self, data_dict):
        # modified from pointnet2
        centroid = np.mean(data_dict["coord"], axis=0)
        data_dict["coord"] -= centroid
        m = np.max(np.linalg.norm(data_dict["coord"], axis=-1))
        data_dict["coord"] = data_dict["coord"] / m

        S_trans = np.eye(4)
        S_trans[:3, 3] = -centroid
        S_rot = np.eye(4)
        S_rot[:3, :3] /= m
        S = S_rot @ S_trans
        S = np.linalg.inv(S)
        for key in self.keys:
            assert key in data_dict.keys()
            for i in range(len(data_dict[key])):
                data_dict[key][i] = data_dict[key][i] @ S

        if "depth_scale" in data_dict.keys():
            data_dict["depth_scale"] /= m
        return data_dict


@TRANSFORMS.register_module()
class PositiveShift(object):
    def __init__(self, keys=[]):
        self.keys = keys

    def __call__(self, data_dict):
        if "coord" in data_dict.keys():
            coord_min = np.min(data_dict["coord"], 0)
            data_dict["coord"] -= coord_min

        S = np.eye(4)
        S[:3, 3] = -coord_min
        S = np.linalg.inv(S)
        for key in self.keys:
            assert key in data_dict.keys()
            for i in range(len(data_dict[key])):
                data_dict[key][i] = data_dict[key][i] @ S
        return data_dict


@TRANSFORMS.register_module()
class CenterShift(object):
    def __init__(self, apply_z=True, keys=[]):
        self.apply_z = apply_z
        self.keys = keys

    def __call__(self, data_dict):
        if len(data_dict["coord"]) == 0:
            return data_dict
        x_min, y_min, z_min = data_dict["coord"].min(axis=0)
        x_max, y_max, _ = data_dict["coord"].max(axis=0)
        if self.apply_z:
            shift = [(x_min + x_max) / 2, (y_min + y_max) / 2, z_min]
        else:
            shift = [(x_min + x_max) / 2, (y_min + y_max) / 2, 0]
        data_dict["coord"] -= shift

        if "obj_click" in data_dict:
            data_dict["obj_click"] -= shift

        S = np.eye(4)
        S[:3, 3] = -np.array(shift)
        S = np.linalg.inv(S)
        
        for key in self.keys:
            assert key in data_dict.keys()
            for i in range(len(data_dict[key])):
                data_dict[key][i] = data_dict[key][i] @ S
        return data_dict


@TRANSFORMS.register_module()
class RandomShift(object):
    def __init__(self, shift=(0.2, 0.2, 0.2), keys=[]):
        self.shift = shift
        self.keys = keys

    def __call__(self, data_dict):
        shift = np.random.normal(scale=self.shift, size=3)
        data_dict["coord"] += shift

        S = np.eye(4)
        S[:3, 3] = shift
        S = np.linalg.inv(S)
        for key in self.keys:
            assert key in data_dict.keys()
            for i in range(len(data_dict[key])):
                data_dict[key][i] = data_dict[key][i] @ S
        return data_dict


@TRANSFORMS.register_module()
class PointClip(object):
    def __init__(self, point_cloud_range=(-80, -80, -3, 80, 80, 1)):
        self.point_cloud_range = point_cloud_range

    def __call__(self, data_dict):
        data_dict["coord"] = np.clip(
            data_dict["coord"],
            a_min=self.point_cloud_range[:3],
            a_max=self.point_cloud_range[3:],
        )
        return data_dict


@TRANSFORMS.register_module()
class PointRangeFilter(object):
    def __init__(self, point_cloud_range=(-80, -80, -3, 80, 80, 1), padding=0.0):
        self.point_cloud_range = point_cloud_range
        self.padding = padding

    def __call__(self, data_dict):
        coord = data_dict["coord"]
        idx = np.nonzero(
            (coord[:, 0] > self.point_cloud_range[0] + self.padding)
            & (coord[:, 1] > self.point_cloud_range[1] + self.padding)
            & (coord[:, 2] > self.point_cloud_range[2] + self.padding)
            & (coord[:, 0] < self.point_cloud_range[3] - self.padding)
            & (coord[:, 1] < self.point_cloud_range[4] - self.padding)
            & (coord[:, 2] < self.point_cloud_range[5] - self.padding)
        )[0]
        data_dict["coord"] = data_dict["coord"][idx]
        if "sampled_index" in data_dict:
            # for ScanNet data efficient, we need to make sure labeled point is sampled.
            idx = np.unique(np.append(idx, data_dict["sampled_index"]))
            mask = np.zeros_like(data_dict["segment"].shape[0]).astype(np.bool)
            mask[data_dict["sampled_index"]] = True
            data_dict["sampled_index"] = np.where(mask[idx])[0]
        if "color" in data_dict.keys():
            data_dict["color"] = data_dict["color"][idx]
        if "normal" in data_dict.keys():
            data_dict["normal"] = data_dict["normal"][idx]
        if "strength" in data_dict.keys():
            data_dict["strength"] = data_dict["strength"][idx]
        if "segment" in data_dict.keys():
            data_dict["segment"] = data_dict["segment"][idx]
        if "instance" in data_dict.keys():
            data_dict["instance"] = data_dict["instance"][idx]
        if "lifted2d_pts_feat" in data_dict.keys():
            data_dict["lifted2d_pts_feat"] = data_dict["lifted2d_pts_feat"][idx]
        if "mask_chunk" in data_dict.keys():
            data_dict["mask_chunk"] = data_dict["mask_chunk"][idx]
        return data_dict


@TRANSFORMS.register_module()
class ProjectOnImage(object):
    def __init__(self, filter_overlap=True, close_radius=0.0):
        self.filter_overlap = filter_overlap
        self.close_radius = close_radius

    def project_on_image(self, coord, lidar2img, img):
        coord = np.concatenate([coord, np.ones_like(coord[:, :1])], axis=-1)
        img_coord, proj_mask = [], []
        for i in range(len(img)):
            i_img, i_lidar2img = img[i], lidar2img[i]
            i_img_coord = coord @ i_lidar2img.T
            eps = 1e-5
            i_img_coord[:, :2] /= np.maximum(i_img_coord[:, 2:3], eps)
            i_proj_mask = (
                (np.linalg.norm(coord[:, :2], axis=-1) > self.close_radius)
                & (i_img_coord[:, 2] > eps)
                & (i_img_coord[:, 0] > 0)
                & (i_img_coord[:, 1] > 0)
                & (i_img_coord[:, 0] < i_img.shape[1])
                & (i_img_coord[:, 1] < i_img.shape[0])
            )
            img_coord.append(i_img_coord[:, :3])
            proj_mask.append(i_proj_mask)
        return img_coord, proj_mask

    def filter_overlap_coord(self, img_coord, proj_mask, img):
        for i in range(len(img)):
            i_mask_idx = np.nonzero(proj_mask[i])[0]
            i_img_coord = img_coord[i][i_mask_idx]
            coord, depth = i_img_coord[:, :2].astype(np.int32), i_img_coord[:, 2]
            rank = coord[:, 0] + coord[:, 1] * img[i].shape[1]
            sort = (rank + depth / 100.0).argsort()
            rank = rank[sort]
            keep = np.ones((rank.shape[0],), dtype=bool)
            keep[1:] = rank[1:] != rank[:-1]
            proj_mask[i][i_mask_idx[sort[~keep]]] = False
        return proj_mask

    def __call__(self, data_dict):
        img = data_dict["img"]
        lidar2img = data_dict["lidar2img"]
        coord = data_dict["coord"]
        img_coord, proj_mask = self.project_on_image(coord, lidar2img, img)
        if self.filter_overlap:
            proj_mask = self.filter_overlap_coord(img_coord, proj_mask, img)
        data_dict["img_coord"] = img_coord
        data_dict["img_proj_mask"] = proj_mask
        return data_dict


@TRANSFORMS.register_module()
class RaySample(object):
    def __init__(
        self, point_nsample, point_ratio=None, fetch_color=True, fetch_segment=True
    ):
        self.point_nsample = point_nsample
        self.point_ratio = point_ratio
        self.fetch_color = fetch_color
        self.fetch_segment = fetch_segment

    def __call__(self, data_dict):
        img_coord = data_dict["img_coord"]
        proj_mask = data_dict["img_proj_mask"]
        lidar2cam = data_dict["lidar2cam"]
        ray_start, ray_end, ray_color, ray_segment = [], [], [], []
        for i in range(len(proj_mask)):
            i_mask_idx = np.nonzero(proj_mask[i])[0]
            point_nsample = min(
                len(i_mask_idx),
                (
                    int(len(i_mask_idx) * self.point_ratio)
                    if self.point_nsample is None
                    else self.point_nsample
                ),
            )
            if point_nsample == 0:
                continue

            i_mask_idx = i_mask_idx[
                np.random.choice(len(i_mask_idx), point_nsample, replace=False)
            ]
            i_img_coord = img_coord[i][i_mask_idx]

            i_ray_start, i_ray_end = (
                np.repeat(
                    np.linalg.inv(lidar2cam[i])[None, :3, 3], len(i_mask_idx), axis=0
                ),
                data_dict["coord"][i_mask_idx],
            )
            if self.fetch_segment:
                ray_segment.append(data_dict["segment"][i_mask_idx])
            if self.fetch_color:
                i_img = data_dict["img"][i]
                i_ray_color = (
                    i_img[
                        i_img_coord[:, 1].astype(np.int32),
                        i_img_coord[:, 0].astype(np.int32),
                    ]
                    / 255.0
                )
                ray_color.append(i_ray_color)
            ray_start.append(i_ray_start)
            ray_end.append(i_ray_end)

        data_dict["ray_start"] = np.concatenate(ray_start, axis=0)
        data_dict["ray_end"] = np.concatenate(ray_end, axis=0)
        if self.fetch_segment:
            data_dict["ray_segment"] = np.concatenate(ray_segment, axis=0)
        if self.fetch_color:
            data_dict["ray_color"] = np.concatenate(ray_color, axis=0)
        return data_dict


@TRANSFORMS.register_module()
class RandomDropout(object):
    def __init__(self, dropout_ratio=0.2, dropout_application_ratio=0.5):
        """
        upright_axis: axis index among x,y,z, i.e. 2 for z
        """
        self.dropout_ratio = dropout_ratio
        self.dropout_application_ratio = dropout_application_ratio

    def __call__(self, data_dict):
        if random.random() < self.dropout_application_ratio:
            n = len(data_dict["coord"])
            idx = np.random.choice(n, int(n * (1 - self.dropout_ratio)), replace=False)
            if not data_dict['superpoint_mask'].shape[0] == n:
                print(data_dict["scene_id"])
            assert data_dict['superpoint_mask'].shape[0] == n
            if "sampled_index" in data_dict:
                # for ScanNet data efficient, we need to make sure labeled point is sampled.
                idx = np.unique(np.append(idx, data_dict["sampled_index"]))
                mask = np.zeros_like(data_dict["segment"].shape[0]).astype(np.bool)
                mask[data_dict["sampled_index"]] = True
                data_dict["sampled_index"] = np.where(mask[idx])[0]
            if "coord" in data_dict.keys():
                data_dict["coord"] = data_dict["coord"][idx]
            if "color" in data_dict.keys():
                data_dict["color"] = data_dict["color"][idx]
            if "normal" in data_dict.keys():
                data_dict["normal"] = data_dict["normal"][idx]
            if "strength" in data_dict.keys():
                data_dict["strength"] = data_dict["strength"][idx]
            if "segment" in data_dict.keys():
                data_dict["segment"] = data_dict["segment"][idx]
            if "instance" in data_dict.keys():
                data_dict["instance"] = data_dict["instance"][idx]
            if "lifted2d_pts_feat" in data_dict.keys():
                data_dict["lifted2d_pts_feat"] = data_dict["lifted2d_pts_feat"][idx]
            if "mask_chunk" in data_dict.keys():
                data_dict["mask_chunk"] = data_dict["mask_chunk"][idx]
            if "superpoint_mask" in data_dict.keys():
                unq_ind, superpoint = np.unique(data_dict['superpoint_mask'][idx], return_inverse=True)
                data_dict["superpoint_mask"] = superpoint
                if "superpoint_feat" in data_dict.keys():
                    data_dict["superpoint_feat"] = data_dict["superpoint_feat"][unq_ind]

        return data_dict


@TRANSFORMS.register_module()
class RandomRotate(object):
    def __init__(
        self,
        angle=None,
        center=None,
        axis="z",
        always_apply=False,
        p=0.5,
        keys=[],
    ):
        self.angle = [-1, 1] if angle is None else angle
        self.axis = axis
        self.always_apply = always_apply
        self.p = p if not self.always_apply else 1
        self.center = center
        self.keys = keys

    def __call__(self, data_dict):
        if len(data_dict['coord']) == 0:
            return data_dict

        if random.random() > self.p:
            return data_dict
        angle = np.random.uniform(self.angle[0], self.angle[1]) * np.pi
        rot_cos, rot_sin = np.cos(angle), np.sin(angle)
        if self.axis == "x":
            rot_t = np.array([[1, 0, 0], [0, rot_cos, -rot_sin], [0, rot_sin, rot_cos]])
        elif self.axis == "y":
            rot_t = np.array([[rot_cos, 0, rot_sin], [0, 1, 0], [-rot_sin, 0, rot_cos]])
        elif self.axis == "z":
            rot_t = np.array([[rot_cos, -rot_sin, 0], [rot_sin, rot_cos, 0], [0, 0, 1]])
        else:
            raise NotImplementedError

        center = self.center
        if self.center is None:
            x_min, y_min, z_min = data_dict["coord"].min(axis=0)
            x_max, y_max, z_max = data_dict["coord"].max(axis=0)
            center = [(x_min + x_max) / 2, (y_min + y_max) / 2, (z_min + z_max) / 2]
        data_dict["coord"] -= center
        data_dict["coord"] = np.dot(data_dict["coord"], np.transpose(rot_t))
        data_dict["coord"] += center

        S_trans1 = np.eye(4)
        S_trans1[:3, 3] = -np.array(center)
        S_rot = np.eye(4)
        S_rot[:3, :3] = rot_t
        S_trans2 = np.eye(4)
        S_trans2[:3, 3] = np.array(center)
        S = S_trans2 @ S_rot @ S_trans1
        S = np.linalg.inv(S)
        for key in self.keys:
            assert key in data_dict.keys()
            for i in range(len(data_dict[key])):
                data_dict[key][i] = data_dict[key][i] @ S

        if "normal" in data_dict.keys():
            data_dict["normal"] = np.dot(data_dict["normal"], np.transpose(rot_t))
        return data_dict


@TRANSFORMS.register_module()
class RandomRotateAlongZWithReference(object):
    def __init__(
        self,
        angle=None,
        center=None,
        always_apply=False,
        p=0.5,
        keys=[],
    ):
        self.angle = [-1, 1] if angle is None else angle
        self.always_apply = always_apply
        self.p = p if not self.always_apply else 1
        self.center = center
        self.keys = keys

        self.relations_to_be_careful = [
            'front', 'behind', 'back', 'left', 'right', 'facing',
            'leftmost', 'rightmost', 'looking', 'across'
        ]
        self.view_dependent_relations = [
            'behind',
            'in front of',
            'on the back of',
            'on the left of',
            'on the left side of',
            'on the right of',
            'on the right side of',
            'to the left of',
            'to the right of'
        ]

    def __call__(self, data_dict):
        if len(data_dict['coord']) == 0:
            return data_dict

        if random.random() > self.p:
            return data_dict

        conversation = data_dict["conversation"]
        question = conversation[0]["value"]
        if any(" " + rel + " " in question for rel in self.relations_to_be_careful) \
                        or any(rel in question for rel in self.view_dependent_relations):
            angle = np.random.uniform(-1/36, 1/36) * np.pi
        else:
            angle = np.random.uniform(self.angle[0], self.angle[1]) * np.pi
        rot_cos, rot_sin = np.cos(angle), np.sin(angle)
        
        rot_t = np.array([[rot_cos, -rot_sin, 0], [rot_sin, rot_cos, 0], [0, 0, 1]])

        center = self.center
        if self.center is None:
            x_min, y_min, z_min = data_dict["coord"].min(axis=0)
            x_max, y_max, z_max = data_dict["coord"].max(axis=0)
            center = [(x_min + x_max) / 2, (y_min + y_max) / 2, (z_min + z_max) / 2]
        data_dict["coord"] -= center
        data_dict["coord"] = np.dot(data_dict["coord"], np.transpose(rot_t))
        data_dict["coord"] += center

        S_trans1 = np.eye(4)
        S_trans1[:3, 3] = -np.array(center)
        S_rot = np.eye(4)
        S_rot[:3, :3] = rot_t
        S_trans2 = np.eye(4)
        S_trans2[:3, 3] = np.array(center)
        S = S_trans2 @ S_rot @ S_trans1
        S = np.linalg.inv(S)
        for key in self.keys:
            assert key in data_dict.keys()
            for i in range(len(data_dict[key])):
                data_dict[key][i] = data_dict[key][i] @ S

        if "normal" in data_dict.keys():
            data_dict["normal"] = np.dot(data_dict["normal"], np.transpose(rot_t))
        return data_dict


@TRANSFORMS.register_module()
class RandomRotateTargetAngle(object):
    def __init__(
        self,
        angle=(1 / 2, 1, 3 / 2),
        center=None,
        axis="z",
        always_apply=False,
        p=0.75,
        keys=[],
    ):
        self.angle = angle
        self.axis = axis
        self.always_apply = always_apply
        self.p = p if not self.always_apply else 1
        self.center = center
        self.keys = keys

    def __call__(self, data_dict):
        if random.random() > self.p:
            return data_dict
        angle = np.random.choice(self.angle) * np.pi
        rot_cos, rot_sin = np.cos(angle), np.sin(angle)
        if self.axis == "x":
            rot_t = np.array([[1, 0, 0], [0, rot_cos, -rot_sin], [0, rot_sin, rot_cos]])
        elif self.axis == "y":
            rot_t = np.array([[rot_cos, 0, rot_sin], [0, 1, 0], [-rot_sin, 0, rot_cos]])
        elif self.axis == "z":
            rot_t = np.array([[rot_cos, -rot_sin, 0], [rot_sin, rot_cos, 0], [0, 0, 1]])
        else:
            raise NotImplementedError
        if self.center is None:
            x_min, y_min, z_min = data_dict["coord"].min(axis=0)
            x_max, y_max, z_max = data_dict["coord"].max(axis=0)
            center = [(x_min + x_max) / 2, (y_min + y_max) / 2, (z_min + z_max) / 2]
        else:
            center = self.center
        data_dict["coord"] -= center
        data_dict["coord"] = np.dot(data_dict["coord"], np.transpose(rot_t))
        data_dict["coord"] += center

        S_trans1 = np.eye(4)
        S_trans1[:3, 3] = -np.array(center)
        S_rot = np.eye(4)
        S_rot[:3, :3] = rot_t
        S_trans2 = np.eye(4)
        S_trans2[:3, 3] = np.array(center)
        S = S_trans2 @ S_rot @ S_trans1
        S = np.linalg.inv(S)
        for key in self.keys:
            assert key in data_dict.keys()
            for i in range(len(data_dict[key])):
                data_dict[key][i] = data_dict[key][i] @ S

        if "normal" in data_dict.keys():
            data_dict["normal"] = np.dot(data_dict["normal"], np.transpose(rot_t))
        return data_dict


@TRANSFORMS.register_module()
class RandomScale(object):
    def __init__(self, scale=None, anisotropic=False, keys=[]):
        self.scale = scale if scale is not None else [0.95, 1.05]
        self.anisotropic = anisotropic
        self.keys = keys

    def __call__(self, data_dict):
        scale = np.random.uniform(
            self.scale[0], self.scale[1], 3 if self.anisotropic else 1
        )
        data_dict["coord"] *= scale

        S = np.eye(4)
        S[:3, :3] *= scale
        S = np.linalg.inv(S)
        for key in self.keys:
            assert key in data_dict.keys()
            for i in range(len(data_dict[key])):
                data_dict[key][i] = data_dict[key][i] @ S

        if "depth_scale" in data_dict.keys():
            assert not self.anisotropic, f"anisotropic not supported yet."
            data_dict["depth_scale"] *= scale
        return data_dict


@TRANSFORMS.register_module()
class RandomFlip(object):
    def __init__(self, p=0.5, keys=[]):
        self.p = p
        self.keys = keys

    def __call__(self, data_dict):
        S = np.eye(4)
        if np.random.rand() < self.p:
            data_dict["coord"][:, 0] = -data_dict["coord"][:, 0]
            S[0, 0] = -1
            if "normal" in data_dict.keys():
                data_dict["normal"][:, 0] = -data_dict["normal"][:, 0]
        if np.random.rand() < self.p:
            data_dict["coord"][:, 1] = -data_dict["coord"][:, 1]
            S[1, 1] = -1
            if "normal" in data_dict.keys():
                data_dict["normal"][:, 1] = -data_dict["normal"][:, 1]

        S = np.linalg.inv(S)
        for key in self.keys:
            assert key in data_dict.keys()
            for i in range(len(data_dict[key])):
                data_dict[key][i] = data_dict[key][i] @ S
        return data_dict


@TRANSFORMS.register_module()
class RandomFlipWithReference(object):
    def __init__(self, p=0.5, keys=[]):
        self.p = p
        self.keys = keys
        self.relations_to_be_careful = [
            'front', 'behind', 'back', 'left', 'right', 'facing',
            'leftmost', 'rightmost', 'looking', 'across'
        ]
        self.view_dependent_relations = [
            'behind',
            'in front of',
            'on the back of',
            'on the left of',
            'on the left side of',
            'on the right of',
            'on the right side of',
            'to the left of',
            'to the right of'
        ]

    def __call__(self, data_dict):
        conversation = data_dict["conversation"]
        question = conversation[0]["value"]
        if any(" " + rel + " " in question for rel in self.relations_to_be_careful):
            return data_dict

        if any(rel in question for rel in self.view_dependent_relations):
            return data_dict

        S = np.eye(4)
        if np.random.rand() < self.p:
            data_dict["coord"][:, 0] = -data_dict["coord"][:, 0]
            S[0, 0] = -1
            if "normal" in data_dict.keys():
                data_dict["normal"][:, 0] = -data_dict["normal"][:, 0]
        if np.random.rand() < self.p:
            data_dict["coord"][:, 1] = -data_dict["coord"][:, 1]
            S[1, 1] = -1
            if "normal" in data_dict.keys():
                data_dict["normal"][:, 1] = -data_dict["normal"][:, 1]

        S = np.linalg.inv(S)
        for key in self.keys:
            assert key in data_dict.keys()
            for i in range(len(data_dict[key])):
                data_dict[key][i] = data_dict[key][i] @ S
        return data_dict


@TRANSFORMS.register_module()
class RandomJitter(object):
    def __init__(self, sigma=0.01, clip=0.05):
        assert clip > 0
        self.sigma = sigma
        self.clip = clip

    def __call__(self, data_dict):
        jitter = np.clip(
            self.sigma * np.random.randn(data_dict["coord"].shape[0], 3),
            -self.clip,
            self.clip,
        )
        data_dict["coord"] += jitter
        return data_dict


@TRANSFORMS.register_module()
class ClipGaussianJitter(object):
    def __init__(self, scalar=0.02, store_jitter=False):
        self.scalar = scalar
        self.mean = np.mean(3)
        self.cov = np.identity(3)
        self.quantile = 1.96
        self.store_jitter = store_jitter

    def __call__(self, data_dict):
        jitter = np.random.multivariate_normal(
            self.mean, self.cov, data_dict["coord"].shape[0]
        )
        jitter = self.scalar * np.clip(jitter / 1.96, -1, 1)
        data_dict["coord"] += jitter
        if self.store_jitter:
            data_dict["jitter"] = jitter
        return data_dict


@TRANSFORMS.register_module()
class ChromaticAutoContrast(object):
    def __init__(self, p=0.2, blend_factor=None):
        self.p = p
        self.blend_factor = blend_factor

    def __call__(self, data_dict):
        if "color" in data_dict.keys() and np.random.rand() < self.p:
            lo = np.min(data_dict["color"], 0, keepdims=True)
            hi = np.max(data_dict["color"], 0, keepdims=True)
            scale = 255 / (hi - lo)
            contrast_feat = (data_dict["color"][:, :3] - lo) * scale
            blend_factor = (
                np.random.rand() if self.blend_factor is None else self.blend_factor
            )
            data_dict["color"][:, :3] = (1 - blend_factor) * data_dict["color"][
                :, :3
            ] + blend_factor * contrast_feat
            if "rgb" in data_dict.keys():
                contrast_feat = (data_dict["rgb"][..., :3] - lo) * scale
                data_dict["rgb"][..., :3] = (1 - blend_factor) * data_dict["rgb"][
                    ..., :3
                ] + blend_factor * contrast_feat
        return data_dict


@TRANSFORMS.register_module()
class ChromaticTranslation(object):
    def __init__(self, p=0.95, ratio=0.05):
        self.p = p
        self.ratio = ratio

    def __call__(self, data_dict):
        if "color" in data_dict.keys() and np.random.rand() < self.p:
            tr = (np.random.rand(1, 3) - 0.5) * 255 * 2 * self.ratio
            data_dict["color"][:, :3] = np.clip(tr + data_dict["color"][:, :3], 0, 255)
            if "rgb" in data_dict.keys():
                data_dict["rgb"][..., :3] = np.clip(
                    tr + data_dict["rgb"][..., :3], 0, 255
                )
        return data_dict


@TRANSFORMS.register_module()
class ChromaticJitter(object):
    def __init__(self, p=0.95, std=0.005):
        self.p = p
        self.std = std

    def __call__(self, data_dict):
        if "color" in data_dict.keys() and np.random.rand() < self.p:
            noise = np.random.randn(data_dict["color"].shape[0], 3)
            noise *= self.std * 255
            data_dict["color"][:, :3] = np.clip(
                noise + data_dict["color"][:, :3], 0, 255
            )
        return data_dict


@TRANSFORMS.register_module()
class RandomColorGrayScale(object):
    def __init__(self, p):
        self.p = p

    @staticmethod
    def rgb_to_grayscale(color, num_output_channels=1):
        if color.shape[-1] < 3:
            raise TypeError(
                "Input color should have at least 3 dimensions, but found {}".format(
                    color.shape[-1]
                )
            )

        if num_output_channels not in (1, 3):
            raise ValueError("num_output_channels should be either 1 or 3")

        r, g, b = color[..., 0], color[..., 1], color[..., 2]
        gray = (0.2989 * r + 0.587 * g + 0.114 * b).astype(color.dtype)
        gray = np.expand_dims(gray, axis=-1)

        if num_output_channels == 3:
            gray = np.broadcast_to(gray, color.shape)

        return gray

    def __call__(self, data_dict):
        if np.random.rand() < self.p:
            data_dict["color"] = self.rgb_to_grayscale(data_dict["color"], 3)
            if "rgb" in data_dict.keys():
                data_dict["rgb"] = self.rgb_to_grayscale(data_dict["rgb"], 3)
        return data_dict


@TRANSFORMS.register_module()
class RandomColorJitter(object):
    """
    Random Color Jitter for 3D point cloud (refer torchvision)
    """

    def __init__(self, brightness=0, contrast=0, saturation=0, hue=0, p=0.95):
        self.brightness = self._check_input(brightness, "brightness")
        self.contrast = self._check_input(contrast, "contrast")
        self.saturation = self._check_input(saturation, "saturation")
        self.hue = self._check_input(
            hue, "hue", center=0, bound=(-0.5, 0.5), clip_first_on_zero=False
        )
        self.p = p

    @staticmethod
    def _check_input(
        value, name, center=1, bound=(0, float("inf")), clip_first_on_zero=True
    ):
        if isinstance(value, numbers.Number):
            if value < 0:
                raise ValueError(
                    "If {} is a single number, it must be non negative.".format(name)
                )
            value = [center - float(value), center + float(value)]
            if clip_first_on_zero:
                value[0] = max(value[0], 0.0)
        elif isinstance(value, (tuple, list)) and len(value) == 2:
            if not bound[0] <= value[0] <= value[1] <= bound[1]:
                raise ValueError("{} values should be between {}".format(name, bound))
        else:
            raise TypeError(
                "{} should be a single number or a list/tuple with length 2.".format(
                    name
                )
            )

        # if value is 0 or (1., 1.) for brightness/contrast/saturation
        # or (0., 0.) for hue, do nothing
        if value[0] == value[1] == center:
            value = None
        return value

    @staticmethod
    def blend(color1, color2, ratio):
        ratio = float(ratio)
        bound = 255.0
        return (
            (ratio * color1 + (1.0 - ratio) * color2)
            .clip(0, bound)
            .astype(color1.dtype)
        )

    @staticmethod
    def rgb2hsv(rgb):
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        maxc = np.max(rgb, axis=-1)
        minc = np.min(rgb, axis=-1)
        eqc = maxc == minc
        cr = maxc - minc
        s = cr / (np.ones_like(maxc) * eqc + maxc * (1 - eqc))
        cr_divisor = np.ones_like(maxc) * eqc + cr * (1 - eqc)
        rc = (maxc - r) / cr_divisor
        gc = (maxc - g) / cr_divisor
        bc = (maxc - b) / cr_divisor

        hr = (maxc == r) * (bc - gc)
        hg = ((maxc == g) & (maxc != r)) * (2.0 + rc - bc)
        hb = ((maxc != g) & (maxc != r)) * (4.0 + gc - rc)
        h = hr + hg + hb
        h = (h / 6.0 + 1.0) % 1.0
        return np.stack((h, s, maxc), axis=-1)

    @staticmethod
    def hsv2rgb(hsv):
        h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
        i = np.floor(h * 6.0)
        f = (h * 6.0) - i
        i = i.astype(np.int32)

        p = np.clip((v * (1.0 - s)), 0.0, 1.0)
        q = np.clip((v * (1.0 - s * f)), 0.0, 1.0)
        t = np.clip((v * (1.0 - s * (1.0 - f))), 0.0, 1.0)
        i = i % 6
        mask = np.expand_dims(i, axis=-1) == np.arange(6)

        a1 = np.stack((v, q, p, p, t, v), axis=-1)
        a2 = np.stack((t, v, v, q, p, p), axis=-1)
        a3 = np.stack((p, p, t, v, v, q), axis=-1)
        a4 = np.stack((a1, a2, a3), axis=-1)

        return np.einsum("...na, ...nab -> ...nb", mask.astype(hsv.dtype), a4)

    def adjust_brightness(self, data_dict, brightness_factor):
        if brightness_factor < 0:
            raise ValueError(
                "brightness_factor ({}) is not non-negative.".format(brightness_factor)
            )
        if "color" in data_dict:
            data_dict["color"] = self.blend(
                data_dict["color"], np.zeros_like(data_dict["color"]), brightness_factor
            )
        if "rgb" in data_dict:
            data_dict["rgb"] = self.blend(
                data_dict["rgb"], np.zeros_like(data_dict["rgb"]), brightness_factor
            )
        return data_dict

    def adjust_contrast(self, data_dict, contrast_factor):
        if contrast_factor < 0:
            raise ValueError(
                "contrast_factor ({}) is not non-negative.".format(contrast_factor)
            )
        mean = np.mean(RandomColorGrayScale.rgb_to_grayscale(data_dict["color"]))
        data_dict["color"] = self.blend(data_dict["color"], mean, contrast_factor)
        if "rgb" in data_dict:
            data_dict["rgb"] = self.blend(data_dict["rgb"], mean, contrast_factor)
        return data_dict

    def adjust_saturation(self, data_dict, saturation_factor):
        if saturation_factor < 0:
            raise ValueError(
                "saturation_factor ({}) is not non-negative.".format(saturation_factor)
            )
        gray = RandomColorGrayScale.rgb_to_grayscale(data_dict["color"])
        data_dict["color"] = self.blend(data_dict["color"], gray, saturation_factor)
        if "rgb" in data_dict:
            gray = RandomColorGrayScale.rgb_to_grayscale(data_dict["rgb"])
            data_dict["rgb"] = self.blend(data_dict["rgb"], gray, saturation_factor)
        return data_dict

    def adjust_hue(self, data_dict, hue_factor):
        if not (-0.5 <= hue_factor <= 0.5):
            raise ValueError(
                "hue_factor ({}) is not in [-0.5, 0.5].".format(hue_factor)
            )
        orig_dtype = data_dict["color"].dtype
        if "rgb" in data_dict:
            color_shape = data_dict["color"].shape
            rgb_shape = data_dict["rgb"].shape
            rgb_orig_dtype = data_dict["rgb"].dtype
            hsv = self.rgb2hsv(
                np.concatenate([data_dict["color"], data_dict["rgb"].reshape(-1, 3)])
                / 255.0
            )
        else:
            hsv = self.rgb2hsv(data_dict["color"] / 255.0)
        h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
        h = (h + hue_factor) % 1.0
        hsv = np.stack((h, s, v), axis=-1)
        if "rgb" in data_dict:
            color_rgb = self.hsv2rgb(hsv) * 255.0
            data_dict["color"] = color_rgb[: color_shape[0], :].astype(orig_dtype)
            data_dict["rgb"] = (
                color_rgb[color_shape[0] :, :].reshape(rgb_shape).astype(rgb_orig_dtype)
            )
        else:
            data_dict["color"] = (self.hsv2rgb(hsv) * 255.0).astype(orig_dtype)
        return data_dict

    @staticmethod
    def get_params(brightness, contrast, saturation, hue):
        fn_idx = torch.randperm(4)
        b = (
            None
            if brightness is None
            else np.random.uniform(brightness[0], brightness[1])
        )
        c = None if contrast is None else np.random.uniform(contrast[0], contrast[1])
        s = (
            None
            if saturation is None
            else np.random.uniform(saturation[0], saturation[1])
        )
        h = None if hue is None else np.random.uniform(hue[0], hue[1])
        return fn_idx, b, c, s, h

    def __call__(self, data_dict):
        (
            fn_idx,
            brightness_factor,
            contrast_factor,
            saturation_factor,
            hue_factor,
        ) = self.get_params(self.brightness, self.contrast, self.saturation, self.hue)

        for fn_id in fn_idx:
            if (
                fn_id == 0
                and brightness_factor is not None
                and np.random.rand() < self.p
            ):
                data_dict = self.adjust_brightness(data_dict, brightness_factor)
            elif (
                fn_id == 1 and contrast_factor is not None and np.random.rand() < self.p
            ):
                data_dict = self.adjust_contrast(data_dict, contrast_factor)
            elif (
                fn_id == 2
                and saturation_factor is not None
                and np.random.rand() < self.p
            ):
                data_dict = self.adjust_saturation(data_dict, saturation_factor)
            elif fn_id == 3 and hue_factor is not None and np.random.rand() < self.p:
                data_dict = self.adjust_hue(data_dict, hue_factor)
        return data_dict


@TRANSFORMS.register_module()
class HueSaturationTranslation(object):
    @staticmethod
    def rgb_to_hsv(rgb):
        # Translated from source of colorsys.rgb_to_hsv
        # r,g,b should be a numpy arrays with values between 0 and 255
        # rgb_to_hsv returns an array of floats between 0.0 and 1.0.
        rgb = rgb.astype("float")
        hsv = np.zeros_like(rgb)
        # in case an RGBA array was passed, just copy the A channel
        hsv[..., 3:] = rgb[..., 3:]
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        maxc = np.max(rgb[..., :3], axis=-1)
        minc = np.min(rgb[..., :3], axis=-1)
        hsv[..., 2] = maxc
        mask = maxc != minc
        hsv[mask, 1] = (maxc - minc)[mask] / maxc[mask]
        rc = np.zeros_like(r)
        gc = np.zeros_like(g)
        bc = np.zeros_like(b)
        rc[mask] = (maxc - r)[mask] / (maxc - minc)[mask]
        gc[mask] = (maxc - g)[mask] / (maxc - minc)[mask]
        bc[mask] = (maxc - b)[mask] / (maxc - minc)[mask]
        hsv[..., 0] = np.select(
            [r == maxc, g == maxc], [bc - gc, 2.0 + rc - bc], default=4.0 + gc - rc
        )
        hsv[..., 0] = (hsv[..., 0] / 6.0) % 1.0
        return hsv

    @staticmethod
    def hsv_to_rgb(hsv):
        # Translated from source of colorsys.hsv_to_rgb
        # h,s should be a numpy arrays with values between 0.0 and 1.0
        # v should be a numpy array with values between 0.0 and 255.0
        # hsv_to_rgb returns an array of uints between 0 and 255.
        rgb = np.empty_like(hsv)
        rgb[..., 3:] = hsv[..., 3:]
        h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
        i = (h * 6.0).astype("uint8")
        f = (h * 6.0) - i
        p = v * (1.0 - s)
        q = v * (1.0 - s * f)
        t = v * (1.0 - s * (1.0 - f))
        i = i % 6
        conditions = [s == 0.0, i == 1, i == 2, i == 3, i == 4, i == 5]
        rgb[..., 0] = np.select(conditions, [v, q, p, p, t, v], default=v)
        rgb[..., 1] = np.select(conditions, [v, v, v, q, p, p], default=t)
        rgb[..., 2] = np.select(conditions, [v, p, t, v, v, q], default=p)
        return rgb.astype("uint8")

    def __init__(self, hue_max=0.5, saturation_max=0.2):
        self.hue_max = hue_max
        self.saturation_max = saturation_max

    def __call__(self, data_dict):
        if "color" in data_dict.keys():
            # Assume color[:, :3] is rgb
            hsv = HueSaturationTranslation.rgb_to_hsv(data_dict["color"][:, :3])
            hue_val = (np.random.rand() - 0.5) * 2 * self.hue_max
            sat_ratio = 1 + (np.random.rand() - 0.5) * 2 * self.saturation_max
            hsv[..., 0] = np.remainder(hue_val + hsv[..., 0] + 1, 1)
            hsv[..., 1] = np.clip(sat_ratio * hsv[..., 1], 0, 1)
            data_dict["color"][:, :3] = np.clip(
                HueSaturationTranslation.hsv_to_rgb(hsv), 0, 255
            )
            if "rgb" in data_dict.keys():
                hsv_rgb = HueSaturationTranslation.rgb_to_hsv(data_dict["rgb"][..., :3])
                hsv_rgb[..., 0] = np.remainder(hue_val + hsv_rgb[..., 0] + 1, 1)
                hsv_rgb[..., 1] = np.clip(sat_ratio * hsv_rgb[..., 1], 0, 1)
                data_dict["rgb"][..., :3] = np.clip(
                    HueSaturationTranslation.hsv_to_rgb(hsv_rgb), 0, 255
                )
        return data_dict


@TRANSFORMS.register_module()
class RandomColorDrop(object):
    def __init__(self, p=0.2, color_augment=0.0):
        self.p = p
        self.color_augment = color_augment

    def __call__(self, data_dict):
        if "color" in data_dict.keys() and np.random.rand() < self.p:
            data_dict["color"] *= self.color_augment
        return data_dict

    def __repr__(self):
        return "RandomColorDrop(color_augment: {}, p: {})".format(
            self.color_augment, self.p
        )


@TRANSFORMS.register_module()
class ElasticDistortion(object):
    def __init__(self, distortion_params=None):
        self.distortion_params = (
            [[0.2, 0.4], [0.8, 1.6]] if distortion_params is None else distortion_params
        )

    @staticmethod
    def elastic_distortion(coords, granularity, magnitude):
        """
        Apply elastic distortion on sparse coordinate space.
        pointcloud: numpy array of (number of points, at least 3 spatial dims)
        granularity: size of the noise grid (in same scale[m/cm] as the voxel grid)
        magnitude: noise multiplier
        """
        blurx = np.ones((3, 1, 1, 1)).astype("float32") / 3
        blury = np.ones((1, 3, 1, 1)).astype("float32") / 3
        blurz = np.ones((1, 1, 3, 1)).astype("float32") / 3
        coords_min = coords.min(0)

        # Create Gaussian noise tensor of the size given by granularity.
        noise_dim = ((coords - coords_min).max(0) // granularity).astype(int) + 3
        noise = np.random.randn(*noise_dim, 3).astype(np.float32)

        # Smoothing.
        for _ in range(2):
            noise = scipy.ndimage.filters.convolve(
                noise, blurx, mode="constant", cval=0
            )
            noise = scipy.ndimage.filters.convolve(
                noise, blury, mode="constant", cval=0
            )
            noise = scipy.ndimage.filters.convolve(
                noise, blurz, mode="constant", cval=0
            )

        # Trilinear interpolate noise filters for each spatial dimensions.
        ax = [
            np.linspace(d_min, d_max, d)
            for d_min, d_max, d in zip(
                coords_min - granularity,
                coords_min + granularity * (noise_dim - 2),
                noise_dim,
            )
        ]
        interp = scipy.interpolate.RegularGridInterpolator(
            ax, noise, bounds_error=False, fill_value=0
        )
        coords += interp(coords) * magnitude
        return coords

    def __call__(self, data_dict):
        if "coord" in data_dict.keys() and self.distortion_params is not None:
            if random.random() < 0.95:
                for granularity, magnitude in self.distortion_params:
                    data_dict["coord"] = self.elastic_distortion(
                        data_dict["coord"], granularity, magnitude
                    )
        return data_dict


@TRANSFORMS.register_module()
class GridSample(object):
    def __init__(
        self,
        grid_size=0.05,
        hash_type="fnv",
        mode="train",
        keys=("coord", "color", "normal", "segment"),
        return_inverse=False,
        return_grid_coord=False,
        return_min_coord=False,
        return_displacement=False,
        project_displacement=False,
    ):
        self.grid_size = grid_size
        self.hash = self.fnv_hash_vec if hash_type == "fnv" else self.ravel_hash_vec
        assert mode in ["train", "test"]
        self.mode = mode
        self.keys = keys
        self.return_inverse = return_inverse
        self.return_grid_coord = return_grid_coord
        self.return_min_coord = return_min_coord
        self.return_displacement = return_displacement
        self.project_displacement = project_displacement

    def __call__(self, data_dict):
        # print('------------------------before grid sampling------------------------')
        # print("max mapping index: ", data_dict["superpoint_mask"].max()+1)
        # print("unique mapping index number: ", torch.unique(data_dict["superpoint_mask"]).shape)
        assert "coord" in data_dict.keys()
        scaled_coord = data_dict["coord"] / np.array(self.grid_size)
        grid_coord = np.floor(scaled_coord).astype(int)
        min_coord = grid_coord.min(0) * np.array(self.grid_size)
        grid_coord -= grid_coord.min(0)
        key = self.hash(grid_coord)
        idx_sort = np.argsort(key)
        key_sort = key[idx_sort]
        _, inverse, count = np.unique(key_sort, return_inverse=True, return_counts=True)
        if self.mode == "train":  # train mode
            idx_select = (
                np.cumsum(np.insert(count, 0, 0)[0:-1])
                + np.random.randint(0, count.max(), count.size) % count
            )
            idx_unique = idx_sort[idx_select]
            if "sampled_index" in data_dict:
                # for ScanNet data efficient, we need to make sure labeled point is sampled.
                idx_unique = np.unique(
                    np.append(idx_unique, data_dict["sampled_index"])
                )
                mask = np.zeros_like(data_dict["segment"].shape[0]).astype(bool)
                mask[data_dict["sampled_index"]] = True
                data_dict["sampled_index"] = np.where(mask[idx_unique])[0]
            if self.return_inverse:
                data_dict["inverse"] = np.zeros_like(inverse)
                data_dict["inverse"][idx_sort] = inverse
            if self.return_grid_coord:
                data_dict["grid_coord"] = grid_coord[idx_unique]
            if self.return_min_coord:
                data_dict["min_coord"] = min_coord.reshape([1, 3])
            if self.return_displacement:
                displacement = (
                    scaled_coord - grid_coord - 0.5
                )  # [0, 1] -> [-0.5, 0.5] displacement to center
                if self.project_displacement:
                    displacement = np.sum(
                        displacement * data_dict["normal"], axis=-1, keepdims=True
                    )
                data_dict["displacement"] = displacement[idx_unique]
            for key in self.keys:
                data_dict[key] = data_dict[key][idx_unique]
                # if key == 'superpoint_mask':
                #     print('inverse shape: ', data_dict["inverse"].shape)
                #     print('superpoint_mask shape: ', data_dict['superpoint_mask'].shape )
                #     data_dict[key][idx_sort] = data_dict[key]
                # else:
                #     data_dict[key] = data_dict[key][idx_unique]
                    

            # print('------------------------after grid sampling------------------------')
            # print("max mapping index: ", data_dict["superpoint_mask"].max()+1)
            # print("unique mapping index number: ", torch.unique(data_dict["superpoint_mask"]).shape)

            return data_dict

        elif self.mode == "test":  # test mode
            data_part_list = []
            for i in range(count.max()):
                idx_select = np.cumsum(np.insert(count, 0, 0)[0:-1]) + i % count
                idx_part = idx_sort[idx_select]
                data_part = dict(index=idx_part)
                if self.return_inverse:
                    data_dict["inverse"] = np.zeros_like(inverse)
                    data_dict["inverse"][idx_sort] = inverse
                if self.return_grid_coord:
                    data_part["grid_coord"] = grid_coord[idx_part]
                if self.return_min_coord:
                    data_part["min_coord"] = min_coord.reshape([1, 3])
                if self.return_displacement:
                    displacement = (
                        scaled_coord - grid_coord - 0.5
                    )  # [0, 1] -> [-0.5, 0.5] displacement to center
                    if self.project_displacement:
                        displacement = np.sum(
                            displacement * data_dict["normal"], axis=-1, keepdims=True
                        )
                    data_dict["displacement"] = displacement[idx_part]
                for key in data_dict.keys():
                    if key in self.keys:
                        data_part[key] = data_dict[key][idx_part]
                    else:
                        data_part[key] = data_dict[key]
                data_part_list.append(data_part)
            return data_part_list
        else:
            raise NotImplementedError

    @staticmethod
    def ravel_hash_vec(arr):
        """
        Ravel the coordinates after subtracting the min coordinates.
        """
        assert arr.ndim == 2
        arr = arr.copy()
        arr -= arr.min(0)
        arr = arr.astype(np.uint64, copy=False)
        arr_max = arr.max(0).astype(np.uint64) + 1

        keys = np.zeros(arr.shape[0], dtype=np.uint64)
        # Fortran style indexing
        for j in range(arr.shape[1] - 1):
            keys += arr[:, j]
            keys *= arr_max[j + 1]
        keys += arr[:, -1]
        return keys

    @staticmethod
    def fnv_hash_vec(arr):
        """
        FNV64-1A
        """
        assert arr.ndim == 2
        # Floor first for negative coordinates
        arr = arr.copy()
        arr = arr.astype(np.uint64, copy=False)
        hashed_arr = np.uint64(14695981039346656037) * np.ones(
            arr.shape[0], dtype=np.uint64
        )
        for j in range(arr.shape[1]):
            hashed_arr *= np.uint64(1099511628211)
            hashed_arr = np.bitwise_xor(hashed_arr, arr[:, j])
        return hashed_arr


@TRANSFORMS.register_module()
class SphereCrop(object):
    def __init__(self, point_max=80000, sample_rate=None, mode="random"):
        self.point_max = point_max
        self.sample_rate = sample_rate
        assert mode in ["random", "center", "all"]
        self.mode = mode

    def __call__(self, data_dict):
        point_max = (
            int(self.sample_rate * data_dict["coord"].shape[0])
            if self.sample_rate is not None
            else self.point_max
        )

        assert "coord" in data_dict.keys()
        if self.mode == "all":
            # TODO: Optimize
            if "index" not in data_dict.keys():
                data_dict["index"] = np.arange(data_dict["coord"].shape[0])
            data_part_list = []
            # coord_list, color_list, dist2_list, idx_list, offset_list = [], [], [], [], []
            if data_dict["coord"].shape[0] > point_max:
                coord_p, idx_uni = (
                    np.random.rand(data_dict["coord"].shape[0]) * 1e-3,
                    np.array([]),
                )
                while idx_uni.size != data_dict["index"].shape[0]:
                    init_idx = np.argmin(coord_p)
                    dist2 = np.sum(
                        np.power(data_dict["coord"] - data_dict["coord"][init_idx], 2),
                        1,
                    )
                    idx_crop = np.argsort(dist2)[:point_max]

                    data_crop_dict = dict()
                    if "coord" in data_dict.keys():
                        data_crop_dict["coord"] = data_dict["coord"][idx_crop]
                    if "grid_coord" in data_dict.keys():
                        data_crop_dict["grid_coord"] = data_dict["grid_coord"][idx_crop]
                    if "normal" in data_dict.keys():
                        data_crop_dict["normal"] = data_dict["normal"][idx_crop]
                    if "color" in data_dict.keys():
                        data_crop_dict["color"] = data_dict["color"][idx_crop]
                    if "displacement" in data_dict.keys():
                        data_crop_dict["displacement"] = data_dict["displacement"][
                            idx_crop
                        ]
                    if "strength" in data_dict.keys():
                        data_crop_dict["strength"] = data_dict["strength"][idx_crop]
                    data_crop_dict["weight"] = dist2[idx_crop]
                    data_crop_dict["index"] = data_dict["index"][idx_crop]
                    data_part_list.append(data_crop_dict)

                    delta = np.square(
                        1 - data_crop_dict["weight"] / np.max(data_crop_dict["weight"])
                    )
                    coord_p[idx_crop] += delta
                    idx_uni = np.unique(
                        np.concatenate((idx_uni, data_crop_dict["index"]))
                    )
            else:
                data_crop_dict = data_dict.copy()
                data_crop_dict["weight"] = np.zeros(data_dict["coord"].shape[0])
                data_crop_dict["index"] = data_dict["index"]
                data_part_list.append(data_crop_dict)
            return data_part_list
        # mode is "random" or "center"
        elif data_dict["coord"].shape[0] > point_max:
            if self.mode == "random":
                center = data_dict["coord"][
                    np.random.randint(data_dict["coord"].shape[0])
                ]
            elif self.mode == "center":
                center = data_dict["coord"][data_dict["coord"].shape[0] // 2]
            else:
                raise NotImplementedError
            idx_crop = np.argsort(np.sum(np.square(data_dict["coord"] - center), 1))[
                :point_max
            ]
            if "coord" in data_dict.keys():
                data_dict["coord"] = data_dict["coord"][idx_crop]
            if "origin_coord" in data_dict.keys():
                data_dict["origin_coord"] = data_dict["origin_coord"][idx_crop]
            if "grid_coord" in data_dict.keys():
                data_dict["grid_coord"] = data_dict["grid_coord"][idx_crop]
            if "color" in data_dict.keys():
                data_dict["color"] = data_dict["color"][idx_crop]
            if "normal" in data_dict.keys():
                data_dict["normal"] = data_dict["normal"][idx_crop]
            if "segment" in data_dict.keys():
                data_dict["segment"] = data_dict["segment"][idx_crop]
            if "superpoint_mask" in data_dict.keys():
                unq_ind, superpoint = np.unique(data_dict['superpoint_mask'][idx_crop], return_inverse=True)
                data_dict["superpoint_mask"] = superpoint
                if "superpoint_feat" in data_dict.keys():
                    data_dict["superpoint_feat"] = data_dict["superpoint_feat"][unq_ind]
            if "instance" in data_dict.keys():
                data_dict["instance"] = data_dict["instance"][idx_crop]
            if "lifted2d_pts_feat" in data_dict.keys():
                data_dict["lifted2d_pts_feat"] = data_dict["lifted2d_pts_feat"][idx_crop]
            if "displacement" in data_dict.keys():
                data_dict["displacement"] = data_dict["displacement"][idx_crop]
            if "strength" in data_dict.keys():
                data_dict["strength"] = data_dict["strength"][idx_crop]
            if "mask_chunk" in data_dict.keys():
                data_dict["mask_chunk"] = data_dict["mask_chunk"][idx_crop]
        return data_dict


@TRANSFORMS.register_module()
class ShufflePoint(object):
    def __call__(self, data_dict):
        assert "coord" in data_dict.keys()
        shuffle_index = np.arange(data_dict["coord"].shape[0])
        np.random.shuffle(shuffle_index)
        if "coord" in data_dict.keys():
            data_dict["coord"] = data_dict["coord"][shuffle_index]
        if "grid_coord" in data_dict.keys():
            data_dict["grid_coord"] = data_dict["grid_coord"][shuffle_index]
        if "displacement" in data_dict.keys():
            data_dict["displacement"] = data_dict["displacement"][shuffle_index]
        if "color" in data_dict.keys():
            data_dict["color"] = data_dict["color"][shuffle_index]
        if "normal" in data_dict.keys():
            data_dict["normal"] = data_dict["normal"][shuffle_index]
        if "segment" in data_dict.keys():
            data_dict["segment"] = data_dict["segment"][shuffle_index]
        if "superpoint_mask" in data_dict.keys():
            data_dict["superpoint_mask"] = data_dict["superpoint_mask"][shuffle_index]
        if "instance" in data_dict.keys():
            data_dict["instance"] = data_dict["instance"][shuffle_index]
        if "lifted2d_pts_feat" in data_dict.keys():
            data_dict["lifted2d_pts_feat"] = data_dict["lifted2d_pts_feat"][shuffle_index]
        if "mask_chunk" in data_dict.keys():
            data_dict["mask_chunk"] = data_dict["mask_chunk"][shuffle_index]
        return data_dict


@TRANSFORMS.register_module()
class CropBoundary(object):
    def __call__(self, data_dict):
        assert "segment" in data_dict
        segment = data_dict["segment"].flatten()
        mask = (segment != 0) * (segment != 1)
        if "coord" in data_dict.keys():
            data_dict["coord"] = data_dict["coord"][mask]
        if "grid_coord" in data_dict.keys():
            data_dict["grid_coord"] = data_dict["grid_coord"][mask]
        if "color" in data_dict.keys():
            data_dict["color"] = data_dict["color"][mask]
        if "normal" in data_dict.keys():
            data_dict["normal"] = data_dict["normal"][mask]
        if "segment" in data_dict.keys():
            data_dict["segment"] = data_dict["segment"][mask]
        if "superpoint_mask" in data_dict.keys():
            unq_ind, superpoint = np.unique(data_dict['superpoint_mask'][mask], return_inverse=True)
            data_dict["superpoint_mask"] = superpoint
            if "superpoint_feat" in data_dict.keys():
                data_dict["superpoint_feat"] = data_dict["superpoint_feat"][unq_ind]
        if "instance" in data_dict.keys():
            data_dict["instance"] = data_dict["instance"][mask]
        if "lifted2d_pts_feat" in data_dict.keys():
            data_dict["lifted2d_pts_feat"] = data_dict["lifted2d_pts_feat"][mask]
        if "mask_chunk" in data_dict.keys():
            data_dict["mask_chunk"] = data_dict["mask_chunk"][mask]
        return data_dict


@TRANSFORMS.register_module()
class ContrastiveViewsGenerator(object):
    def __init__(
        self,
        view_keys=("coord", "color", "normal", "origin_coord"),
        view_trans_cfg=None,
    ):
        self.view_keys = view_keys
        self.view_trans = Compose(view_trans_cfg)

    def __call__(self, data_dict):
        view1_dict = dict()
        view2_dict = dict()
        for key in self.view_keys:
            view1_dict[key] = data_dict[key].copy()
            view2_dict[key] = data_dict[key].copy()
        view1_dict = self.view_trans(view1_dict)
        view2_dict = self.view_trans(view2_dict)
        for key, value in view1_dict.items():
            data_dict["view1_" + key] = value
        for key, value in view2_dict.items():
            data_dict["view2_" + key] = value
        return data_dict


@TRANSFORMS.register_module()
class InstanceParser(object):
    def __init__(self, segment_ignore_index=(-1, 0, 1), instance_ignore_index=-1):
        self.segment_ignore_index = segment_ignore_index
        self.instance_ignore_index = instance_ignore_index

    def __call__(self, data_dict):
        coord = data_dict["coord"]
        segment = data_dict["segment"]
        instance = data_dict["instance"]
        mask = ~np.in1d(segment, self.segment_ignore_index)
        # mapping ignored instance to ignore index
        instance[~mask] = self.instance_ignore_index
        # reorder left instance
        unique, inverse = np.unique(instance[mask], return_inverse=True)
        instance_num = len(unique)
        instance[mask] = inverse
        # init instance information
        centroid = np.ones((coord.shape[0], 3)) * self.instance_ignore_index
        bbox = np.ones((instance_num, 8)) * self.instance_ignore_index
        vacancy = [
            index for index in self.segment_ignore_index if index >= 0
        ]  # vacate class index

        for instance_id in range(instance_num):
            mask_ = instance == instance_id
            coord_ = coord[mask_]
            bbox_min = coord_.min(0)
            bbox_max = coord_.max(0)
            bbox_centroid = coord_.mean(0)
            bbox_center = (bbox_max + bbox_min) / 2
            bbox_size = bbox_max - bbox_min
            bbox_theta = np.zeros(1, dtype=coord_.dtype)
            bbox_class = np.array([segment[mask_][0]], dtype=coord_.dtype)
            # shift class index to fill vacate class index caused by segment ignore index
            bbox_class -= np.greater(bbox_class, vacancy).sum()

            centroid[mask_] = bbox_centroid
            bbox[instance_id] = np.concatenate(
                [bbox_center, bbox_size, bbox_theta, bbox_class]
            )  # 3 + 3 + 1 + 1 = 8
        data_dict["instance"] = instance
        data_dict["instance_centroid"] = centroid
        data_dict["bbox"] = bbox
        return data_dict


@TRANSFORMS.register_module()
class VoxelizationInfo(object):
    def __init__(
        self,
        grid_size=0.05,
        mode="train",
    ):
        self.grid_size = grid_size
        self.mode = mode
        
    def __call__(self, data_dict):
        assert "coord" in data_dict.keys()
        if "elastic_coord" in data_dict.keys():
            scaled_coord = data_dict["elastic_coord"]
        else:
            scaled_coord = data_dict["coord"] / np.array(self.grid_size)

        scaled_coord -= scaled_coord.min(0)
        grid_coord = scaled_coord.astype(int)
        data_dict["grid_coord"] = grid_coord
        
        if self.mode == "train":
            return data_dict
        elif self.mode == "test":
            return [data_dict]
        else:
            raise ValueError("mode can only be train or test")


@TRANSFORMS.register_module()
class RandomCrop(object):
    def __init__(self, point_max=80000):
        self.point_max = point_max

    def __call__(self, data_dict):

        if data_dict["coord"].shape[0] > self.point_max:
            center = data_dict["coord"][
                np.random.randint(data_dict["coord"].shape[0])
            ]
            
            idx_crop = np.argsort(np.sum(np.square(data_dict["coord"] - center), 1))[
                :self.point_max
            ]
            if "coord" in data_dict.keys():
                data_dict["coord"] = data_dict["coord"][idx_crop]
            if "origin_coord" in data_dict.keys():
                data_dict["origin_coord"] = data_dict["origin_coord"][idx_crop]
            if "grid_coord" in data_dict.keys():
                data_dict["grid_coord"] = data_dict["grid_coord"][idx_crop]
            if "color" in data_dict.keys():
                data_dict["color"] = data_dict["color"][idx_crop]
            if "normal" in data_dict.keys():
                data_dict["normal"] = data_dict["normal"][idx_crop]
            if "segment" in data_dict.keys():
                data_dict["segment"] = data_dict["segment"][idx_crop]
            if "superpoint_mask" in data_dict.keys():
                unq_ind, superpoint = np.unique(data_dict['superpoint_mask'][idx_crop], return_inverse=True)
                data_dict["superpoint_mask"] = superpoint
                if "superpoint_feat" in data_dict.keys():
                    data_dict["superpoint_feat"] = data_dict["superpoint_feat"][unq_ind]
                # data_dict["superpoint_mask"] = data_dict["superpoint_mask"][idx_crop]

            if "instance" in data_dict.keys():
                data_dict["instance"] = data_dict["instance"][idx_crop]
            if "lifted2d_pts_feat" in data_dict.keys():
                data_dict["lifted2d_pts_feat"] = data_dict["lifted2d_pts_feat"][idx_crop]
            if "displacement" in data_dict.keys():
                data_dict["displacement"] = data_dict["displacement"][idx_crop]
            if "strength" in data_dict.keys():
                data_dict["strength"] = data_dict["strength"][idx_crop]
            if "mask_chunk" in data_dict.keys():
                data_dict["mask_chunk"] = data_dict["mask_chunk"][idx_crop]
        return data_dict


@TRANSFORMS.register_module()
class LoadSuperpoint(object):
    def __init__(self, 
                 data_root="./data/scannet", 
                 lifted_split="openseg_superpoint_features",
                 load_lifted_feature=False
                 ):
        
        self.data_root = data_root
        self.split = lifted_split
        self.load_feat = load_lifted_feature

    def __call__(self, data_dict):
        assert "scene_id" in data_dict.keys()
        scene_id = data_dict["scene_id"]
        superpoint_path = os.path.join(self.data_root, "super_points", f"{scene_id}.bin")
        superpoint_mask = np.fromfile(superpoint_path, dtype=np.int64)

        data_dict["superpoint_mask"] = superpoint_mask

        if self.load_feat:
            feat_path = os.path.join(self.data_root, self.split, f"{scene_id}_superpoint_feature.pt")
            superpoint_feat = torch.load(feat_path)
            data_dict["superpoint_feat"] = superpoint_feat.numpy()
        
        return data_dict


@TRANSFORMS.register_module()
class AddSuperPointAnnotations(object):
    """Prepare ground truth markup for training.
    
    Required Keys:
    - pts_semantic_mask (np.float32)
    
    Added Keys:
    - gt_sp_masks (np.int64)
    
    Args:
        num_classes (int): Number of classes.
    """
    
    def __init__(self,
                 num_classes=20,
                 stuff_classes=[0, 1],
                 add_sem_mask=True,
                 add_inst_anno=False,
                 merge_non_stuff_cls=True):
        self.num_classes = num_classes
        self.stuff_classes = stuff_classes
        self.add_sem_mask = add_sem_mask
        self.add_inst_anno = add_inst_anno
        self.merge_non_stuff_cls = merge_non_stuff_cls
        
 
    def __call__(self, input_dict):
        """Private function for preparation ground truth 
        markup for training.
        
        Args:
            input_dict (dict): Result dict from loading pipeline.
        
        Returns:
            dict: results, 'gt_sp_masks' is added.
        """
        # # create class mapping
        # # because pts_instance_mask contains instances from non-instaces classes
        # pts_instance_mask = torch.tensor(input_dict['instance'])
        # pts_semantic_mask = torch.tensor(input_dict['segment'])
        
        # pts_instance_mask[pts_semantic_mask == -1] = -1
        # for stuff_cls in self.stuff_classes:
        #     pts_instance_mask[pts_semantic_mask == stuff_cls] = -1
        
        # idxs = torch.unique(pts_instance_mask)
        # assert idxs[0] == -1

        # mapping = torch.zeros(torch.max(idxs) + 2, dtype=torch.long)
        # new_idxs = torch.arange(len(idxs), device=idxs.device)
        # mapping[idxs] = new_idxs - 1
        # pts_instance_mask = mapping[pts_instance_mask]
        # input_dict['instance'] = pts_instance_mask.numpy()


        # create class mapping
        # because pts_instance_mask contains instances from non-instaces classes
        pts_instance_mask = torch.tensor(input_dict['instance'])
        pts_semantic_mask = torch.tensor(input_dict['segment'])

        # # the loaded ignored anno for pts is 0, change it to self.num_classes
        pts_semantic_mask[pts_semantic_mask==-1] = self.num_classes
        pts_instance_mask += 1

        pts_instance_mask[pts_semantic_mask == self.num_classes] = -1
        for stuff_cls in self.stuff_classes:
            pts_instance_mask[pts_semantic_mask == stuff_cls] = -1
        
        idxs = torch.unique(pts_instance_mask)
        # assert idxs[0] == -1

        mapping = torch.zeros(torch.max(idxs) + 2, dtype=torch.long)
        new_idxs = torch.arange(len(idxs), device=idxs.device)
        mapping[idxs] = new_idxs - 1
        pts_instance_mask = mapping[pts_instance_mask]
        input_dict['instance'] = pts_instance_mask.numpy()

        # create gt instance markup     
        insts_mask = pts_instance_mask.clone()
        
        if torch.sum(insts_mask == -1) != 0:
            insts_mask[insts_mask == -1] = torch.max(insts_mask) + 1
            insts_mask = torch.nn.functional.one_hot(insts_mask)[:, :-1]
        else:
            insts_mask = torch.nn.functional.one_hot(insts_mask)

        if insts_mask.shape[1] != 0:
            insts_mask = insts_mask.T
            sp_pts_mask = torch.tensor(input_dict['superpoint_mask'])
            sp_masks_inst = scatter(
                insts_mask.float(), sp_pts_mask.long(), reduce="mean", dim=-1
            )
            # sp_masks_inst = scatter_mean(
            #     insts_mask.float(), sp_pts_mask, dim=-1)
            sp_masks_inst = sp_masks_inst > 0.5
        else:
            sp_masks_inst = insts_mask.new_zeros(
                (0, input_dict['superpoint_mask'].max() + 1), dtype=torch.bool)

        num_stuff_cls = len(self.stuff_classes)
        insts = new_idxs[1:] - 1

        if self.merge_non_stuff_cls:
            gt_labels = insts.new_zeros(len(insts) + num_stuff_cls + 1)
        else:
            gt_labels = insts.new_zeros(len(insts) + self.num_classes + 1)

        for inst in insts:
            index = pts_semantic_mask[pts_instance_mask == inst][0]
            gt_labels[inst] = index - num_stuff_cls
        
        input_dict['gt_labels_3d'] = gt_labels.numpy()

        if self.add_sem_mask:
            # create gt semantic markup
            sem_mask = torch.tensor(input_dict['segment'])
            # # the loaded ignored anno for pts is 0, change it to self.num_classes
            sem_mask[sem_mask==-1] = self.num_classes
            sem_mask = torch.nn.functional.one_hot(sem_mask, 
                                        num_classes=self.num_classes + 1)


            sem_mask = sem_mask.T
            sp_pts_mask = torch.tensor(input_dict['superpoint_mask'])
            sp_masks_seg = scatter(sem_mask.float(), sp_pts_mask.long(), reduce="mean", dim=-1)
            # sp_masks_seg = scatter_mean(sem_mask.float(), sp_pts_mask, dim=-1)
            sp_masks_seg = sp_masks_seg > 0.5

            sp_masks_seg[-1, sp_masks_seg.sum(axis=0) == 0] = True

            assert sp_masks_seg.sum(axis=0).max().item()
            
            if self.merge_non_stuff_cls:
                sp_masks_seg = torch.vstack((
                    sp_masks_seg[:num_stuff_cls, :], 
                    sp_masks_seg[num_stuff_cls:, :].sum(axis=0).unsqueeze(0)))
            
            sp_masks_all = torch.vstack((sp_masks_inst, sp_masks_seg))
        else:
            sp_masks_all = sp_masks_inst

        input_dict['gt_inst_sp_masks'] = sp_masks_all.numpy()

        # create eval markup
        if 'eval_ann_info' in input_dict.keys(): 
            pts_instance_mask[pts_instance_mask != -1] += num_stuff_cls
            for idx, stuff_cls in enumerate(self.stuff_classes):
                pts_instance_mask[pts_semantic_mask == stuff_cls] = idx

            input_dict['eval_ann_info']['instance'] = \
                pts_instance_mask.numpy()

        return input_dict


@TRANSFORMS.register_module()
class AddSuperPointAnnotationsV2(object):
    """Prepare ground truth markup for training.
    
    Required Keys:
    - pts_semantic_mask (np.float32)
    
    Added Keys:
    - gt_sp_masks (np.int64)
    
    Args:
        num_classes (int): Number of classes.
    """
    
    def __init__(self,
                 num_classes=20,
                 stuff_classes=[0, 1],
                 add_sem_mask=True,
                 ):
        self.num_classes = num_classes
        self.stuff_classes = stuff_classes
        self.add_sem_mask = add_sem_mask
        
    def __call__(self, input_dict):
        """Private function for preparation ground truth 
        markup for training.
        
        Args:
            input_dict (dict): Result dict from loading pipeline.
        
        Returns:
            dict: results, 'gt_sp_masks' is added.
        """
        # create class mapping
        # because pts_instance_mask contains instances from non-instaces classes
        pts_instance_mask = torch.tensor(input_dict['instance'])
        pts_semantic_mask = torch.tensor(input_dict['segment'])

        # # the loaded ignored anno for pts is 0, change it to self.num_classes
        pts_semantic_mask[pts_semantic_mask==-1] = self.num_classes
        pts_instance_mask += 1

        pts_instance_mask[pts_semantic_mask == self.num_classes] = -1
        for stuff_cls in self.stuff_classes:
            pts_instance_mask[pts_semantic_mask == stuff_cls] = -1
        
        idxs = torch.unique(pts_instance_mask)
        assert idxs[0] == -1

        mapping = torch.zeros(torch.max(idxs) + 2, dtype=torch.long)
        new_idxs = torch.arange(len(idxs), device=idxs.device)
        mapping[idxs] = new_idxs - 1
        pts_instance_mask = mapping[pts_instance_mask]
        input_dict['instance'] = pts_instance_mask.numpy()

        # create gt instance markup     
        insts_mask = pts_instance_mask.clone()
        
        if torch.sum(insts_mask == -1) != 0:
            insts_mask[insts_mask == -1] = torch.max(insts_mask) + 1
            insts_mask = torch.nn.functional.one_hot(insts_mask)[:, :-1]
        else:
            insts_mask = torch.nn.functional.one_hot(insts_mask)

        if insts_mask.shape[1] != 0:
            insts_mask = insts_mask.T
            sp_pts_mask = torch.tensor(input_dict['superpoint_mask'])
            sp_masks_inst = scatter(
                insts_mask.float(), sp_pts_mask.long(), reduce="mean", dim=-1
            )
            # sp_masks_inst = scatter_mean(
            #     insts_mask.float(), sp_pts_mask, dim=-1)
            sp_masks_inst = sp_masks_inst > 0.5
        else:
            sp_masks_inst = insts_mask.new_zeros(
                (0, input_dict['superpoint_mask'].max() + 1), dtype=torch.bool)

        num_stuff_cls = len(self.stuff_classes)
        insts = new_idxs[1:] - 1

        gt_labels = insts.new_zeros(len(insts))
        for inst in insts:
            index = pts_semantic_mask[pts_instance_mask == inst][0]
            gt_labels[inst] = index - num_stuff_cls
        
        input_dict['gt_inst_labels'] = gt_labels.numpy()

        if self.add_sem_mask:
            # create gt semantic markup
            sem_mask = torch.tensor(input_dict['segment'])
            # # the loaded ignored anno for pts is 0, change it to self.num_classes
            sem_mask[sem_mask==-1] = self.num_classes
            sem_mask = torch.nn.functional.one_hot(sem_mask, 
                                        num_classes=self.num_classes + 1)

            sem_mask = sem_mask.T
            sp_pts_mask = torch.tensor(input_dict['superpoint_mask'])
            sp_masks_seg = scatter(sem_mask.float(), sp_pts_mask.long(), reduce="mean", dim=-1)
            # sp_masks_seg = scatter_mean(sem_mask.float(), sp_pts_mask, dim=-1)
            sp_masks_seg = sp_masks_seg > 0.5

            sp_masks_seg[-1, sp_masks_seg.sum(axis=0) == 0] = True

            assert sp_masks_seg.sum(axis=0).max().item()
            
            input_dict["gt_sem_masks"] = sp_masks_seg.numpy()

        input_dict["gt_inst_masks"] = sp_masks_inst.numpy()

        # create eval markup
        if 'eval_ann_info' in input_dict.keys(): 
            pts_instance_mask[pts_instance_mask != -1] += num_stuff_cls
            for idx, stuff_cls in enumerate(self.stuff_classes):
                pts_instance_mask[pts_semantic_mask == stuff_cls] = idx

            input_dict['eval_ann_info']['instance'] = \
                pts_instance_mask.numpy()

        return input_dict


@TRANSFORMS.register_module()
class AddReferredSuperPointMask(object):
    """Prepare ground truth markup for training.
    
    Required Keys:
    - pts_semantic_mask (np.float32)
    
    Added Keys:
    - gt_sp_masks (np.int64)
    
    Args:
        num_classes (int): Number of classes.
    """
    
    def __call__(self, input_dict):
        """Private function for preparation ground truth 
        markup for training.
        
        Args:
            input_dict (dict): Result dict from loading pipeline.
        
        Returns:
            dict: results, 'gt_sp_masks' is added.
        """
        segment = torch.tensor(input_dict["segment"])
        sp_pts_mask = torch.tensor(input_dict["superpoint_mask"])
        sp_masks = scatter(
            segment.float(), sp_pts_mask.long(), reduce="mean", dim=-1
        )
        sp_masks = sp_masks > 0.5
        input_dict["gt_refer_masks"] = sp_masks.unsqueeze(0).numpy()

        return input_dict


@TRANSFORMS.register_module()
class LoadLiftedFeature(object):
    def __init__(self, 
                 feat_root='/data/datasets/SOLE/cache/openseg/scannet'
                 ):
        
        self.data_root = feat_root

    def __call__(self, data_dict):
        assert "scene_id" in data_dict.keys()
        scene_id = data_dict["scene_id"]
        lifted_feat_path = os.path.join(self.data_root, f"{scene_id}_0.pt")
        pts_lifted2d_feat = torch.load(lifted_feat_path).numpy()
        data_dict["lifted2d_pts_feat"] = pts_lifted2d_feat

        return data_dict


@TRANSFORMS.register_module()
class LoadLiftedInstFeature(object):
    def __init__(self, 
                 data_root="./data/scannet", 
                 split="scannet200_openseg_lifted2d_inst_features",
                 ):
        
        self.data_root = data_root
        self.split = split

    def __call__(self, data_dict):
        assert "scene_id" in data_dict.keys()
        scene_id = data_dict["scene_id"]
        # superpoint_path = os.path.join(self.data_root, "super_points", f"{scene_id}.bin")
        # superpoint_mask = np.fromfile(superpoint_path, dtype=np.int64)

        # data_dict["superpoint_mask"] = superpoint_mask

        inst_feat_path = os.path.join(self.data_root, self.split, f"{scene_id}_lifted_inst_feature.pt")
        inst_feat_dict = torch.load(inst_feat_path)
        data_dict["lifted2d_inst_feat_dict"] = inst_feat_dict
        # print(inst_feat.shape, data_dict["gt_inst_sp_masks"].shape)
        # assert inst_feat.shape[0] == data_dict["gt_inst_sp_masks"].shape[0]

        return data_dict


@TRANSFORMS.register_module()
class ElasticDistortionV2(object):
    def __init__(self, gran, mag, grid_size, p=1.0):
        self.gran = gran
        self.mag = mag
        self.p = p
        self.grid_size = grid_size

    def elastic(self, x, gran, mag):
        """Private function for elastic transform to a points.

        Args:
            x (ndarray): Point cloud.
            gran (List[float]): Size of the noise grid (in same scale[m/cm]
                as the voxel grid).
            mag: (List[float]): Noise multiplier.
        
        Returns:
            dict: Results after elastic, 'points' is updated
                in the result dict.
        """
        blur0 = np.ones((3, 1, 1)).astype('float32') / 3
        blur1 = np.ones((1, 3, 1)).astype('float32') / 3
        blur2 = np.ones((1, 1, 3)).astype('float32') / 3

        noise_dim = np.abs(x).max(0).astype(np.int32) // gran + 3
        noise = [
            np.random.randn(noise_dim[0], noise_dim[1],
                            noise_dim[2]).astype('float32') for _ in range(3)
        ]

        for blur in [blur0, blur1, blur2, blur0, blur1, blur2]:
            noise = [
                scipy.ndimage.filters.convolve(
                    n, blur, mode='constant', cval=0) for n in noise
            ]

        ax = [
            np.linspace(-(b - 1) * gran, (b - 1) * gran, b) for b in noise_dim
        ]
        interp = [
            scipy.interpolate.RegularGridInterpolator(
                ax, n, bounds_error=0, fill_value=0) for n in noise
        ]

        return x + np.hstack([i(x)[:, None] for i in interp]) * mag

    def __call__(self, data_dict):
        coords = copy.deepcopy(data_dict['coord']) / self.grid_size
        if np.random.rand() < self.p:
            coords = self.elastic(coords, self.gran[0], self.mag[0])
            coords = self.elastic(coords, self.gran[1], self.mag[1])
        data_dict['elastic_coord'] = coords
        return data_dict
        

@TRANSFORMS.register_module()
class JitterFlipRotate(object):
    def __init__(self, 
                 jitter=True,
                 flip=True,
                 rot=True,
                 ):
        
        self.jitter = jitter
        self.flip = flip
        self.rot = rot

    def __call__(self, data_dict):
        m = np.eye(3)
        if self.jitter:
            m += np.random.randn(3, 3) * 0.1
        if self.flip:
            m[0][0] *= np.random.randint(0, 2) * 2 - 1  # flip x randomly
            m[1][1] *= np.random.randint(0, 2) * 2 - 1  # flip y randomly
        if self.rot:
            theta = np.random.rand() * 2 * math.pi
            m = np.matmul(
                m,
                [[math.cos(theta), math.sin(theta), 0], [-math.sin(theta), math.cos(theta), 0], [0, 0, 1]])  # rotation
        
        if "normal" in data_dict.keys():
            data_dict["normal"] = np.matmul(data_dict["normal"], m)
        
        data_dict["coord"] = np.matmul(data_dict["coord"], m)
        
        return data_dict


@TRANSFORMS.register_module()
class GlobalRotScaleTrans(object):
    def __init__(self, 
                 rot_range: List[float] = [-0.78539816, 0.78539816],
                 scale_ratio_range: List[float] = [0.95, 1.05],
                 translation_std: List[int] = [0, 0, 0],
                 ):
        self.rot_range = rot_range
        self.scale_ratio_range = scale_ratio_range
        self.translation_std = translation_std
    
    def __call__(self, data_dict):
        # rotation
        rotation = self.rot_range
        theta = np.random.uniform(rotation[0], rotation[1])

        rot_mat = np.array(
            [[math.cos(theta), math.sin(theta), 0], [-math.sin(theta), math.cos(theta), 0], [0, 0, 1]]
        )
        data_dict["coord"] = np.matmul(data_dict["coord"], rot_mat)

        # scale
        scale_factor = np.random.uniform(self.scale_ratio_range[0],
                                         self.scale_ratio_range[1])
        data_dict["coord"] *= scale_factor

        # translation
        translation_std = np.array(self.translation_std, dtype=np.float32)
        trans_factor = np.random.normal(scale=translation_std, size=3).T
        data_dict["coord"] += trans_factor[None, :]

        return data_dict


@TRANSFORMS.register_module()
class AddDataType(object):
    def __init__(self, 
                 dataset,
                ):
        self.dataset = dataset

    def __call__(self, data_dict):
        # ScanNet:   0
        # ScanRefer: 1
        if self.dataset == "ScanNet":
            data_dict["data_type"] == 0
        elif self.dataset == "ScanRefer":
            data_dict["data_type"] == 1

        return data_dict


@TRANSFORMS.register_module()
class AddSuperPointAnnotationsPlaceHolder(object):
    def __call__(self, data_dict):
        data_dict["gt_labels_3d"] = []
        data_dict["gt_inst_sp_masks"] = []
            
        return data_dict


@TRANSFORMS.register_module()
class AddReferredSuperPointMaskPlaceHolder(object):
    def __call__(self, data_dict):
        data_dict["gt_refer_masks"] = []
        data_dict["pooled_embed"] = []
        data_dict["last_hidden_embed"] = []
        data_dict["description"] = []
            
        return data_dict


@TRANSFORMS.register_module()
class AddSPPanoAnnotations(object):
    """Prepare ground truth markup for training.
    
    Required Keys:
    - pts_semantic_mask (np.float32)
    
    Added Keys:
    - gt_sp_masks (np.int64)
    
    Args:
        num_classes (int): Number of classes.
    """
    
    def __init__(self,
                 num_classes=20,
                 stuff_classes=[0, 1],
                 ):
        self.num_classes = num_classes
        self.stuff_classes = stuff_classes
        
    def __call__(self, input_dict):
        """Private function for preparation ground truth 
        markup for training.
        
        Args:
            input_dict (dict): Result dict from loading pipeline.
        
        Returns:
            dict: results, 'gt_sp_masks' is added.
        """
        # create class mapping
        # because pts_instance_mask contains instances from non-instaces classes
        pts_instance_mask = torch.tensor(input_dict['instance'])
        pts_semantic_mask = torch.tensor(input_dict['segment'])

        # # the loaded ignored anno for pts is 0, change it to self.num_classes
        pts_semantic_mask[pts_semantic_mask==-1] = self.num_classes
        pts_instance_mask += 1

        pts_instance_mask[pts_semantic_mask == self.num_classes] = -1
        for stuff_cls in self.stuff_classes:
            pts_instance_mask[pts_semantic_mask == stuff_cls] = -1
        
        idxs = torch.unique(pts_instance_mask)
        assert idxs[0] == -1

        mapping = torch.zeros(torch.max(idxs) + 2, dtype=torch.long)
        new_idxs = torch.arange(len(idxs), device=idxs.device)
        mapping[idxs] = new_idxs - 1
        pts_instance_mask = mapping[pts_instance_mask]
        # input_dict['instance'] = pts_instance_mask.numpy()

        # create gt instance markup     
        insts_mask = pts_instance_mask.clone()
        
        if torch.sum(insts_mask == -1) != 0:
            insts_mask[insts_mask == -1] = torch.max(insts_mask) + 1
            insts_mask = torch.nn.functional.one_hot(insts_mask)[:, :-1]
        else:
            insts_mask = torch.nn.functional.one_hot(insts_mask)

        if insts_mask.shape[1] != 0:
            insts_mask = insts_mask.T
            sp_pts_mask = torch.tensor(input_dict['superpoint_mask'])
            sp_masks_inst = scatter(
                insts_mask.float(), sp_pts_mask.long(), reduce="mean", dim=-1
            )
            # sp_masks_inst = scatter_mean(
            #     insts_mask.float(), sp_pts_mask, dim=-1)
            sp_masks_inst = sp_masks_inst > 0.5
        else:
            sp_masks_inst = insts_mask.new_zeros(
                (0, input_dict['superpoint_mask'].max() + 1), dtype=torch.bool)

        num_stuff_cls = len(self.stuff_classes)
        insts = new_idxs[1:] - 1

        gt_labels = insts.new_zeros(len(insts))
        for inst in insts:
            index = pts_semantic_mask[pts_instance_mask == inst][0]
            gt_labels[inst] = index #  - num_stuff_cls
        
        # input_dict['gt_inst_labels'] = gt_labels.numpy()

        # create gt semantic markup
        sem_mask = torch.tensor(input_dict['segment'])
        # # the loaded ignored anno for pts is 0, change it to self.num_classes
        sem_mask[sem_mask==-1] = self.num_classes
        sem_mask = torch.nn.functional.one_hot(sem_mask, 
                                    num_classes=self.num_classes + 1)

        sem_mask = sem_mask.T
        sp_pts_mask = torch.tensor(input_dict['superpoint_mask'])
        sp_masks_seg = scatter(sem_mask.float(), sp_pts_mask.long(), reduce="mean", dim=-1)
        # sp_masks_seg = scatter_mean(sem_mask.float(), sp_pts_mask, dim=-1)
        sp_masks_seg = sp_masks_seg > 0.5
        sp_masks_seg[-1, sp_masks_seg.sum(axis=0) == 0] = True
        assert sp_masks_seg.sum(axis=0).max().item()
        
        sp_masks_stuff = sp_masks_seg[self.stuff_classes]
        gt_labels_stuff = torch.tensor(self.stuff_classes)

        masks_pano = torch.cat([sp_masks_inst, sp_masks_stuff], dim=0)
        labels_pano = torch.cat([gt_labels, gt_labels_stuff], dim=0)

        input_dict["gt_masks_3d"] = masks_pano
        input_dict["gt_labels_3d"] = labels_pano

        # create eval markup
        if 'eval_ann_info' in input_dict.keys(): 
            pts_instance_mask[pts_instance_mask != -1] += num_stuff_cls
            for idx, stuff_cls in enumerate(self.stuff_classes):
                pts_instance_mask[pts_semantic_mask == stuff_cls] = idx

            input_dict['eval_ann_info']['instance'] = \
                pts_instance_mask.numpy()
                
        return input_dict


@TRANSFORMS.register_module()
class AddReferTarget(object):
    def __call__(self, data_dict):
        instance  = data_dict["instance"]
        object_id = data_dict["object_id"]
        p2s_map   = data_dict["superpoint_mask"]

        if not isinstance(object_id,list):
            object_id = [object_id]
        
        pt_segment = np.isin(instance, object_id)
        pt_segment = torch.tensor(pt_segment)
        p2s_map = torch.tensor(p2s_map)
        
        sp_segment = scatter(
            pt_segment.float(), p2s_map.long(), reduce="mean", dim=-1
        )
        
        gt_masks_3d = sp_segment > 0.5
        gt_labels_3d = torch.tensor([0])

        data_dict["gt_masks_3d"]  = gt_masks_3d.unsqueeze(0)
        data_dict["gt_labels_3d"] = gt_labels_3d.unsqueeze(0)
        
        return data_dict


@TRANSFORMS.register_module()
class Refer2InstanceMask(object):
    def __call__(self, data_dict):
        instance  = data_dict["instance"]
        object_id = data_dict["object_id"]

        if not isinstance(object_id,list):
            object_id = [object_id]
        
        pt_segment = np.isin(instance, object_id)
        
        data_dict["instance"]  = pt_segment
        
        return data_dict


@TRANSFORMS.register_module()
class GetReferSegSuperPointAnno(object):
    def __call__(self, data_dict):
        pt_segment  = data_dict["instance"]
        p2s_map   = data_dict["superpoint_mask"]

        pt_segment = torch.tensor(pt_segment)
        p2s_map = torch.tensor(p2s_map)
        
        sp_segment = scatter(
            pt_segment.float(), p2s_map.long(), reduce="mean", dim=-1
        )
        
        gt_masks_3d = sp_segment > 0.5
        gt_labels_3d = torch.tensor([0])

        data_dict["gt_masks_3d"]  = gt_masks_3d.unsqueeze(0)
        data_dict["gt_labels_3d"] = gt_labels_3d.unsqueeze(0)
        
        return data_dict


@TRANSFORMS.register_module()
class RandomDropoutWithReference(object):
    def __init__(self, dropout_ratio=0.2, dropout_application_ratio=0.5):
        """
        upright_axis: axis index among x,y,z, i.e. 2 for z
        """
        self.dropout_ratio = dropout_ratio
        self.dropout_application_ratio = dropout_application_ratio

    def __call__(self, data_dict):
        if random.random() < self.dropout_application_ratio:
            instance = data_dict["instance"]
            fg_idx = np.where(instance > 0)[0]
            fg_n = len(fg_idx)            
            fg_idx = fg_idx[np.random.choice(fg_n, int(fg_n * (1 - self.dropout_ratio)), replace=False)]

            n = len(data_dict["coord"])
            idx = np.random.choice(n, int(n * (1 - self.dropout_ratio)), replace=False)
            idx = np.union1d(fg_idx, idx)

            if not data_dict['superpoint_mask'].shape[0] == n:
                print(data_dict["scene_id"])
            assert data_dict['superpoint_mask'].shape[0] == n
            if "sampled_index" in data_dict:
                # for ScanNet data efficient, we need to make sure labeled point is sampled.
                idx = np.unique(np.append(idx, data_dict["sampled_index"]))
                mask = np.zeros_like(data_dict["segment"].shape[0]).astype(np.bool)
                mask[data_dict["sampled_index"]] = True
                data_dict["sampled_index"] = np.where(mask[idx])[0]
            if "coord" in data_dict.keys():
                data_dict["coord"] = data_dict["coord"][idx]
            if "color" in data_dict.keys():
                data_dict["color"] = data_dict["color"][idx]
            if "normal" in data_dict.keys():
                data_dict["normal"] = data_dict["normal"][idx]
            if "strength" in data_dict.keys():
                data_dict["strength"] = data_dict["strength"][idx]
            if "segment" in data_dict.keys():
                data_dict["segment"] = data_dict["segment"][idx]
            if "instance" in data_dict.keys():
                data_dict["instance"] = data_dict["instance"][idx]
            if "lifted2d_pts_feat" in data_dict.keys():
                data_dict["lifted2d_pts_feat"] = data_dict["lifted2d_pts_feat"][idx]
            if "mask_chunk" in data_dict.keys():
                data_dict["mask_chunk"] = data_dict["mask_chunk"][idx]
            if "superpoint_mask" in data_dict.keys():
                unq_ind, superpoint = np.unique(data_dict['superpoint_mask'][idx], return_inverse=True)
                data_dict["superpoint_mask"] = superpoint
                if "superpoint_feat" in data_dict.keys():
                    data_dict["superpoint_feat"] = data_dict["superpoint_feat"][unq_ind]

        return data_dict


@TRANSFORMS.register_module()
class SceneAlignment(object):
    def __init__(self, file_path):
        with open(file_path, "rb") as f:
            import pickle
            axis_align_info = pickle.load(f)
        self.axis_align_info = axis_align_info

    def __call__(self, data_dict):
        scene_id = data_dict["scene_id"]
        coord = data_dict["coord"]
        axis_align_matrix = self.axis_align_info[scene_id]
        axis_align_matrix = np.array(axis_align_matrix)
        pts = np.ones((coord.shape[0], 4))
        pts[:, :3] = coord
        pts = np.dot(pts, axis_align_matrix.transpose()) # Nx4
        aligned_coord = copy.deepcopy(pts[:, :3])
        data_dict["coord"] = aligned_coord

        return data_dict


@TRANSFORMS.register_module()
class Mask2Box(object):
    def __init__(self, is_train=False):
        self.is_train = is_train

    def __call__(self, data_dict):
        pt_segment = data_dict["instance"]
        p2s_map = data_dict["superpoint_mask"]
        coord = data_dict["coord"]

        obj_coord = coord[pt_segment]
        xyz_min = obj_coord.min(dim=0).values
        xyz_max = obj_coord.max(dim=0).values
        center = (xyz_max + xyz_min) / 2.0
        size = xyz_max - xyz_min
        obj_box = torch.cat((center, size))
 
        if self.is_train:
            std_dev = size / 4.0
            noise = torch.randn(3) * std_dev
            obj_click = center + noise
            obj_click = torch.clamp(obj_click, center - size/3, center + size /3)
        
        sp_segment = scatter(
            pt_segment.float(), p2s_map.long(), reduce="mean", dim=-1
        )
        
        obj_superpoint_mask = sp_segment > 0.45
        data_dict["obj_box"] = obj_box
        data_dict["obj_click"] = obj_click
        data_dict["obj_sp_mask"] = obj_superpoint_mask

        return data_dict


@TRANSFORMS.register_module()
class GetContinualSuperpointMask(object):
    def __call__(self, data_dict):
        unq_ind, superpoint = np.unique(data_dict['superpoint_mask'], return_inverse=True)
        data_dict["superpoint_mask"] = superpoint
        if "superpoint_feat" in data_dict.keys():
                data_dict["superpoint_feat"] = data_dict["superpoint_feat"][unq_ind]
        return data_dict
    

@TRANSFORMS.register_module()
class PredBox2Click(object):
    def __init__(self, det_file):
        self.det_all = torch.load(det_file)

    def __call__(self, data_dict):
        scene_id = data_dict["scene_id"]
        pred_id = data_dict["pred_id"]
        det_boxes = self.det_all[scene_id]["locs"]
        cur_box = copy.deepcopy(det_boxes[pred_id])
        click = cur_box[:3].numpy()
        data_dict["obj_click"] = click
        return data_dict


class Compose(object):
    def __init__(self, cfg=None):
        self.cfg = cfg if cfg is not None else []
        self.transforms = []
        for t_cfg in self.cfg:
            self.transforms.append(TRANSFORMS.build(t_cfg))

    def __call__(self, data_dict):
        for t in self.transforms:
            data_dict = t(data_dict)
        return data_dict

